public abstract class Person {
    public abstract void performRole();
}
