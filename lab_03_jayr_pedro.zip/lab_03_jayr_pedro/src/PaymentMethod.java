public interface PaymentMethod {
    double calculatePayment(double fare, double distance);
}
